# @useweave/cli-linux-x64

Native optional dependency for @useweave/cli@0.1.0.

Executable SHA-256: `4d3588b2bdb7c31bc8c98914e3e62836752071f781104389dad7659df3c86f1c`
