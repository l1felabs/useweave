# @useweave/cli-linux-arm64

Native optional dependency for @useweave/cli@0.1.0.

Executable SHA-256: `fbd45b8d597833f46c01f57f956127b1cd39623a7eedea19f146251cb097a96f`
