# @useweave/cli-darwin-arm64

Native optional dependency for @useweave/cli@0.1.0.

Executable SHA-256: `4734ab0f44a691fcdc0178b63bb8afbf30664264404a5e63e844a2f3ded8523b`
