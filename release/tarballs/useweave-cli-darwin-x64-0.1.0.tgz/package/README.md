# @useweave/cli-darwin-x64

Native optional dependency for @useweave/cli@0.1.0.

Executable SHA-256: `61829314dbfef992ac777abeb5a26ff3ad80bc44766e770c657e46154282980c`
