# @useweave/cli-linux-arm64

Native optional dependency for `@useweave/cli@0.2.1`.

Linux GLIBC2.39 or later; OpenSSL3 shared libraries additionally required.

The npm package version is 0.2.1; the executable reports 0.1.0 and runtime API 2. It speaks the Weave Kademlia protocol `/weave/kad/1.0.0` by default. The private Rust source is not included in this public distribution.

Executable SHA-256: `6e926f850fbc15742b609b62a0550e050307705357ab3c1ae18ff456a43fe03b`
