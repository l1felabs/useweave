# @useweave/cli-linux-x64

Native optional dependency for `@useweave/cli@0.2.1`.

Linux GLIBC2.39 or later.

The npm package version is 0.2.1; the executable reports 0.1.0 and runtime API 2. It speaks the Weave Kademlia protocol `/weave/kad/1.0.0` by default. The private Rust source is not included in this public distribution.

Executable SHA-256: `9315e17015c151447dcc8d91a6cc5800b8fb6993d6597c36bf3a50fa4f2a1c7f`
