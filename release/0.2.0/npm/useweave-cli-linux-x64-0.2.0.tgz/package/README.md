# @useweave/cli-linux-x64

Native optional dependency for `@useweave/cli@0.2.0`.

Linux GLIBC2.39 or later.

The npm package version is 0.2.0; the executable reports 0.1.0 and runtime API 2. The private Rust source is not included in this public distribution.

Executable SHA-256: `66139dfb0dbecf4304b0014830ddfea50d24e96825f49b758bc0b6589d704783`
