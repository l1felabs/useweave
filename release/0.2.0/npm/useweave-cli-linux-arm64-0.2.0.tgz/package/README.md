# @useweave/cli-linux-arm64

Native optional dependency for `@useweave/cli@0.2.0`.

Linux GLIBC2.39 or later; OpenSSL3 shared libraries additionally required.

The npm package version is 0.2.0; the executable reports 0.1.0 and runtime API 2. The private Rust source is not included in this public distribution.

Executable SHA-256: `961502cdd92aa61df9568340eee25152c056f523f0a73a15c6b3180db44fe2fc`
