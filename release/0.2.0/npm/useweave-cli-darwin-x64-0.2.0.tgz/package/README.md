# @useweave/cli-darwin-x64

Native optional dependency for `@useweave/cli@0.2.0`.

macOS11 or later; stock system libraries.

The npm package version is 0.2.0; the executable reports 0.1.0 and runtime API 2. The private Rust source is not included in this public distribution.

Executable SHA-256: `4f527ef1565d59179cd5ab92b3ffdc1618bda60cbd4dadd9eab797e3b46add56`
