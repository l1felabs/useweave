# @useweave/cli-darwin-arm64

Native optional dependency for `@useweave/cli@0.2.0`.

macOS11 or later; stock system libraries.

The npm package version is 0.2.0; the executable reports 0.1.0 and runtime API 2. The private Rust source is not included in this public distribution.

Executable SHA-256: `f51a1d09a22739c46579bf0ff0c5bb5ea6547e1f569930bf7d371bc3aa31a90f`
